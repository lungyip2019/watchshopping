<?php
/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\SeoExtended\Controller;

class RegistryConstants
{
    const CURRENT_CATEGORY_FILTER_CONSTANT = 'current_categoryfilter_id';
}
