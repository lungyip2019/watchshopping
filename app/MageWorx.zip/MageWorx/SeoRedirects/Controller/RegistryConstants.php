<?php
/**
 * Copyright © 2017 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\SeoRedirects\Controller;

class RegistryConstants
{
    const CURRENT_REDIRECT_CONSTANT = 'current_redirect';
    const CUSTOM_REDIRECT_FORM_DATA_KEY = 'redirect';
}
